import { sum } from "../sum";
test("check sum", () => {
  expect(sum(2, 3)).toBe(5);
});
