# Food-Villa
A Food Delivery App created using ReactJS

Fetched Data from Swiggy APIs to populate  restaurant cards.
