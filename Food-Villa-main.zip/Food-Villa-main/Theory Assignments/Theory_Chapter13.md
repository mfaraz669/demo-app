**1. What are different types of testing?**
i. Manual Testing - Testing done manually by people.
ii. Automated Testing - Code testing the code. ex Using tools like Selenium.
iii. end-to-end Testing = Testing the whole flow. SImulating a user going to website, logging in, search, the whole flow is tested in headless browsers(browsers without viewport/UI)
iv. Unit Testing - Testing small units/components of the code.
v. Integration Testing - Testing Integration between components. ex- on searching certain keyword, UI should change

**2. What is Enzyme?**
Enzyme is a Javascript Test utility used for testing React before React Testing Library came into picture. Enzyme was released in 2015. react-testing-library was released in 2018

**3. Enzyme vs React Testing Library**
Enzyme: JavaScript Testing utilities for React, by Airbnb. Enzyme is a JavaScript Testing utility for React that makes it easier to assert, manipulate, and traverse your React Components' output; react-testing-library: A lightweight solution for testing React components. It is a simple and complete React DOM testing utility that encourage good testing practices. It provides light utility functions on top of react-dom and react-dom/test-utils, in a way that encourages better testing practices.

Enzyme and react-testing-library are primarily classified as "Javascript Testing Framework" and "Testing Frameworks" tools respectively.

**4. What is Jest and why do we use it?**
Jest is a Javascript Testing Framework by Facebook. It is used most commonly for unit testing. Unit testing is when you provide input to a unit of code(usually, a function) and match the output with the expected output.
